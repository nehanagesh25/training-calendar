﻿using System.Collections;
using TraingCalanderModel.Model;

namespace TrainingCalendarRepository.Repository.Abstract
{
    public interface ICourse
    {
        bool AddCourse(CourseDetails course);
        IEnumerable GetCourse(CourseDetails course);
        IEnumerable allCourses();
        bool RemoveCourse(CourseDetails course);
        bool UpdateCourse(CourseDetails course);

    }
}
