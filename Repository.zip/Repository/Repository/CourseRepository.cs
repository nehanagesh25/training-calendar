﻿using System;
using System.Collections;
using System.Linq;
using TraingCalanderModel.Model;
using TrainingCalendarRepository.Model;
using TrainingCalendarRepository.Repository.Abstract;
using CourseDetail = TrainingCalendarRepository.Model.CourseDetail;

namespace TrainingCalendarRepository.Repository
{
    public class CourseRepository : ICourse
    {
        private readonly Training_CalendarEntities _db;
        public CourseRepository()
        {
            _db = new Training_CalendarEntities();
        }
        public bool AddCourse(CourseDetails course)
        {

            try
            {
                var newCourse = new CourseDetail
                {
                    Course_Name = course.Course_Name,
                    Description = course.Description,
                    Created_On = DateTime.Now,
                    Duration = course.Duration,
                    Trainer_ID = course.Trainer_ID,
                    Updated_On = course.Updated_On,
                    Created_By = course.Created_By
                };
                _db.CourseDetails.Add(newCourse);
                _db.SaveChanges();
                return true;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public IEnumerable  GetCourse(CourseDetails course)
        {
            try
            {
                var result = from u in _db.CourseDetails
                             where u.Course_Name == course.Course_Name 
                             select new CourseDetails
                             {
                                 Course_Name = u.Course_Name,
                                 Description = u.Description,
                                 Created_On = u.Created_On,
                                 Duration = u.Duration,
                                 Trainer_ID = u.Trainer_ID,
                                 Updated_On = u.Updated_On

                             };
                if(result.Count()> 0)
                {
                    return result;
                }else
                {
                    return result = null;
                }
            }
            catch(Exception e)
            {
                throw e;
                
            }
        }
        public IEnumerable allCourses()
        {
            try
            {
                return (from u in _db.CourseDetails select u);
               
            }
            catch(Exception e)
            {
                throw e;
            }
           
        }

        public bool RemoveCourse(CourseDetails course)
        {
            try
            {
                var x = (from y in _db.CourseDetails
                         where y.Course_Name == course.Course_Name && y.Trainer_ID == course.Trainer_ID
                         select y).FirstOrDefault();
                _db.CourseDetails.Remove(x);
                _db.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
                
            }
        }

        public bool UpdateCourse(CourseDetails course)
        {
            try
            {
                var result = from u in _db.CourseDetails
                             where u.Course_Name == course.Course_Name && u.Trainer_ID == course.Trainer_ID
                             select u;
                foreach (CourseDetail u in result)
                {
                    u.Trainer_ID = course.Trainer_ID;
                    u.Course_Name = course.Course_Name;
                    u.Description = course.Description;
                    u.Created_On = course.Created_On;
                    u.Duration = course.Duration;
                    u.Updated_On = course.Updated_On;

                    // Insert any additional changes to column values.
                }                
                _db.SaveChanges();
                return true;
            }
            catch(Exception)
            {
                return false;
            }
            
        }
    }
}
